package com.example.lenovo.fruit;

/**
 * Created by lenovo on 2016/8/1.
 */
public class FruitAdaper {
}
